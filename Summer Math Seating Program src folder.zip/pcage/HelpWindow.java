package pcage;

import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class HelpWindow extends Stage {
	private TextArea help = new TextArea("Summer Math Seating Program Help"
			+ "\n\nThe Excel spreadsheet must contain one student's data per row."
			+ "\n\nThe first row is not read by the program."
			+ "\n\nThe rest of this help section you must write yourself."
			+ "\n\nCheers, Skylar"
			+ "\n\nP.S. The lead programmer doesn't have to be the only programmer.");
	public HelpWindow() {
		help.setEditable(false);
		help.setFont(new Font("Times New Roman",20));
		help.setWrapText(true);
		Scene helpScene = new Scene(help, 551, 400);
		setScene(helpScene);
		initModality(Modality.APPLICATION_MODAL);
		setTitle("Help");
		show();
	}
	
}