package pcage;
/**
 * An object to sort the Students from the input file.
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class StudentSorter {
	
	private ArrayList<ArrayList<Student>> output = new ArrayList<ArrayList<Student>>();
	
	public StudentSorter(ArrayList<Student> s) {
		for(int i=0; i<5; i++) {
			ArrayList<Student> tmp = new ArrayList<Student>();
			for(Student person:s) {
				tmp.add(new Student(person));
			}
			output.add(tmp);
			for(Student kiddo:output.get(i)) {
				String randomSeat = (""+(int)(Math.random()*26)+(char)((int)(Math.random()*26) + 'A'));
				kiddo.setSeat(randomSeat);
				System.out.println(kiddo.getSeat());
			}
		}
	}
	
	public ArrayList<ArrayList<Student>> sort() {
		return output;
	}
}